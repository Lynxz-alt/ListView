import android.R
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var items: ArrayList<String>? = null
    private var adapter: ArrayAdapter<String>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_item)

        // Initialize the ListView and Buttons
        val listView = findViewById<ListView>(R.id.list)
        val addButton = findViewById<Button>(R.id.button1)
        val deleteButton = findViewById<Button>(R.id.button2)

        // Initialize the ArrayList with some initial data
        items = ArrayList()
        items!!.add("1")
        items!!.add("2")
        items!!.add("3")
        items!!.add("4")
        items!!.add("5")

        // Set up the ArrayAdapter with the initial data
        adapter = ArrayAdapter(
            this, R.layout.simple_list_item_1,
            items!!
        )
        listView.adapter = adapter

        // Set up the Button's click listener to add new items to the ListView
        addButton.setOnClickListener { // Add a new item based on the current size of the items list
            val newItemNumber = items!!.size + 1
            items!!.add(newItemNumber.toString())

            // Notify the adapter of the data change to refresh the ListView
            adapter!!.notifyDataSetChanged()
        }

        // Set up the delete button's click listener to remove the first item
        deleteButton.setOnClickListener {
            // Check if there are items to remove
            if (!items!!.isEmpty()) {
                items!!.removeAt(0) // Remove the first item
                adapter!!.notifyDataSetChanged() // Refresh the ListView
            } else {
                Toast.makeText(
                    this@MainActivity,
                    "No items to delete",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // Set up the ListView's item click listener to display a Toast with the selected item
        listView.onItemClickListener =
            OnItemClickListener { parent: AdapterView<*>?, view: View?, position: Int, id: Long ->
                // Get the selected item
                val selectedItem = items!![position]

                // Show a Toast message with the selected item
                Toast.makeText(
                    this@MainActivity,
                    "Selected: $selectedItem",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }
}